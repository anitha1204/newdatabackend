
const Newfile = require("../models/newfileModel");


// Save a new mapping
exports.newfiledata = async (req, res) => {
  try {
    const { almName, qtestId } = req.body;
    const Newdatafile = await Valuefile.findOne({"entities.Fields.Name": almName}).select("Name");
    
    const Newdata = new Valuefile(req.body);  
    res.status(201).json({ data: Newdatafile, message: "Mapping saved successfull"})
    
} catch (error) {
    res.status(500).json({ message: "Error saving mapping", error });
}
};

  // Get all mappings
  
  


  



