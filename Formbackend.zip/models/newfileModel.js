const mongoose = require("mongoose");

const newfileSchema = new mongoose.Schema({
 
  almName: String,
  qtestId: mongoose.Schema.Types.ObjectId,
  Name: String,
  value: String
});

module.exports = mongoose.model("Newfile", newfileSchema);
